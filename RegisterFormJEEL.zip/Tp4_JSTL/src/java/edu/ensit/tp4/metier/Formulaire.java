/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ensit.tp4.metier;
import edu.ensit.tp4.modele.Exceptiondeschamps;
import edu.ensit.tp4.modele.Utilisateur;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author ASUS
 */
public class Formulaire {
    private static final String CHAMP_PRENOM  = "prenom";
    private static final String CHAMP_PASS  = "motdepasse";
    private static final String CHAMP_CONF   = "confirmation";
    private static final String CHAMP_NOM    = "nom";
    private static final String CHAMP_NOMCompte   = "nomcompte";
    private static final String CHAMP_EMAIL  = "email";
    private static final String CHAMP_SUJET  = "sujet";
    private static final String MSG_SUCCES = "Vous êtes inscrits avec les informations suivantes:";
    Utilisateur utilisateur=new Utilisateur();
    Map<String,String> erreurs=new HashMap<>();
    public String msg;
    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
    

public  Formulaire( HttpServletRequest request ) {
 try{
     utilisateur.setNom(request.getParameter(CHAMP_NOM));
   
 }catch(Exceptiondeschamps ex){
    erreurs.put(CHAMP_NOM, "Le nom d'utilisateur doit contenir au moins 3 caractères.");
}
 try{
     utilisateur.setPrenom(request.getParameter(CHAMP_PRENOM));
   
 }catch(Exceptiondeschamps ex){
    erreurs.put(CHAMP_PRENOM, "Le prénom d'utilisateur doit contenir au moins 3 caractères.");
}
 /*try{
     utilisateur.setNomDeCompte(request.getParameter(CHAMP_NOMCompte));
   
 }catch(Exceptiondeschamps ex){
    erreurs.put(CHAMP_NOMCompte, "Le nom du compte doit contenir au moins 5 caractères.");
}*/
 try{
     utilisateur.setMotDePasse(request.getParameter(CHAMP_PASS));
      if(!utilisateur.getMotDePasse().equals(request.getParameter(CHAMP_CONF)))
      erreurs.put(CHAMP_CONF,"Les mots de passe entrés sont différents, merci de les saisir à nouveau.");
   
 }catch(Exceptiondeschamps ex){
    erreurs.put(CHAMP_PASS, "Le mot de passe  doit contenir au moins six caractères.");
}
try{
     utilisateur.setEmail(request.getParameter(CHAMP_EMAIL));
 }catch(Exceptiondeschamps ex){
    erreurs.put(CHAMP_EMAIL, "L'email doit contenir au moins 8 caractères.");
}
try{
     utilisateur.setSujet(request.getParameter(CHAMP_SUJET));
 }catch(Exceptiondeschamps ex){
    erreurs.put(CHAMP_SUJET, "Le sujet doit contenir au moins cinq caractères.");
}
}

    public Utilisateur getUtilisateur() {
        return utilisateur;
    }

    public void setUtilisateur(Utilisateur utilisateur) {
        this.utilisateur = utilisateur;
    }

    public Map<String, String> getErreurs() {
        return erreurs;
    }

    public void setErreurs(Map<String, String> erreurs) {
        this.erreurs = erreurs;
    }

private void validationMotsDePasse( String motDePasse, String confirmation ) throws Exception {
    if ( motDePasse != null && confirmation != null ) {
        if ( !motDePasse.equals( confirmation ) ) {
               throw new Exception( "Les mots de passe entrés sont différents, merci de les saisir à nouveau." );
        } else if ( motDePasse.length() < 3 ) {
            throw new Exception( "Les mots de passe doivent contenir au moins 3 caractères." );
        }
    } else {
        throw new Exception( "Merci de saisir et confirmer votre mot de passe." );
    }
    if(erreurs.isEmpty()){
        msg=MSG_SUCCES;
    }
}



/*
 * Méthode utilitaire qui retourne null si un champ est vide, et son contenu
 * sinon.
 */
   

}
        
