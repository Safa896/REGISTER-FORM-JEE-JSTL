/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ensit.tp4.controleur;

import edu.ensit.tp4.metier.Formulaire;
import edu.ensit.tp4.modele.Utilisateur;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ASUS
 */
@WebServlet(name = "Controlleur", urlPatterns = {"/Controlleur"})
public class Controlleur extends HttpServlet {
    public static final String ATT_USER = "utilisateur";
    public static final String ATT_FORM = "form";
    String url = "/WEB-INF/vue.jsp";
            
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/* Affichage de la page d'inscription */
        request.getRequestDispatcher( url ).forward( request, response );
	}
 
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// The URL to send data to (JSP FILE)
		
		/*String Name = request.getParameter("nom");
		String LastName = request.getParameter("prenom");
		String Account = request.getParameter("nomDeCompte");
                String Password=request.getParameter("motDePasse");
                String Confirmation=request.getParameter("confirmation");*/
		Formulaire form=new Formulaire( request);
		/*Utilisateur cust = Utilisateur(Name,LastName,Account,Password,Confirmation);*/
		request.setAttribute( ATT_FORM, form );
                /*request.setAttribute( ATT_USER, cust );*/
		
		// Forward data to vue.jsp
		request.getRequestDispatcher( url ).forward( request, response );
		
	}
	
        /* Stockage du formulaire et du bean dans l'objet request */
       
       

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
   
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     *

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
  
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private Utilisateur Utilisateur(String Name, String LastName, String Account, String Password, String Confirmation) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    

}

		
    
	
    